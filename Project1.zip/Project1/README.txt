Name: Jay Shin (shin.810@osu.edu)
Anyone I had discussions with: Nobody

Files:
    - Fun.java: Enumuration for all reserved keywords and special symbols for the "Fun" language. 
    - Main.java: Main Java class that initializes the Scanner object and runs it. 
                 It can be compiled with the command "Javac Main.java" and 
                 executed with the command "Java Main Correct/#.code" (replace # with a number).
    - Scanner.java: A class that reads input text files and outputs a stream of tokens from the Fun.java enumeration. 
    - tester.sh: Test shell script. It can be run by the command "sh tester.sh". 
    - Correct: A folder that contains 13 correct test cases and their expected outputs. 
    - Error: A folder that contains 4 incorrect test cases. 
    - README.txt: Description and overview of this project.

Speical features + comments: Nothing really. Just a basic scanner.
Bugs: Not that I know of. 